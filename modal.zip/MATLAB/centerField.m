function [ x,y ] = centerField( m,n,s,a,b )
%UNTITLED10 Summary of this function goes here
%   Detailed explanation goes here
    x=a+s*m;
    y=b+s*m;
end

