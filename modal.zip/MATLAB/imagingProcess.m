function [ g ] = imagingProcess( image,i,j,size,s )
%UNTITLED9 Summary of this function goes here
%   Detailed explanation goes here
    

end

