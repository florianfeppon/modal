% % f0=imread('lena.jpg');
% % n=size(f0,1);
% % f1=(imcrop(f0,[1,1,127,127]));
% % m=size(f1,1);
% % f2=(imcrop(f0,[10,10,127,127]));
% % [output Greg] = dftregistration(fft2(f1),fft2(f2),10);
% 
 i=50;j=50;index=getIndex(i,j,n);
 imageplot(squeeze(P(i,j,:,:)),'origin',1,2,1);
% for k=1:9
% [i1,j1]=getIJ(IDX(index,k),n);
% output=dftregistration(fft2(squeeze(P(i,j,:,:))),fft2(squeeze(P(i1,j1,:,:))),10);
% imageplot(squeeze(P(i1,j1,:,:)),k,3,3,k);
% %disp(output);
% disp([-output(4),output(3)]);
% end

% k=2;
% for k=1:9
% a=i*s+A(i,j,k)*s;
% b=i*s+B(i,j,k)*s;
% a1=a-w*s;
% a2=a+w*s;
% b1=b-w*s;
% b2=b+w*s;
% disp(a1);
% M=psfed(a1:s:a2,b1:s:b2);
% %M=M(1:s:size(M,1),1:s:size(M,2));
% [i1,j1]=getIJ(IDX(index,k),n);
% imageplot(squeeze(P(i,j,:,:)),'o',9,3,3*k-2);
% imageplot(squeeze(P(i1,j1,:,:)),'N',9,3,3*k-1);
% imageplot(M,'n',9,3,3*k);
% end

imageplot(squeeze(P(i1,j1,:,:)),'',1,2,1);
imageplot(M,'',1,2,2);