function [ a,b ] = getMisalignment( s )
%GETMISALIGNMENT Summary of this function goes here
%   Detailed explanation goes here


end

