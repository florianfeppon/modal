function [ index ] = getIndex(i,j,n )
%UNTITLED7 Summary of this function goes here
%   Detailed explanation goes here
index=(j-1)*n+i;

end

