function [ i,j ] = getIJ( index,n )
%UNTITLED6 Summary of this function goes here
%   Detailed explanation goes here
 i=mod(index-1,n)+1;
 j=floor(index/n)+1;
end

