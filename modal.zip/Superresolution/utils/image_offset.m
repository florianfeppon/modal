function [P] = image_offset( F, s, l1 ,l2)
%	Computes the image, with subpixel offset of (l1/s, l2/s)
    B=size(F);
    N=B(1,1);
    P=zeros(N);
    for i=1:N
        for j=1:N
            P(i,j)=(s-l1)*(s-l2)*F(i,j);
            if i<N && j<N 
                P(i,j)=P(i,j)+l1*l2*F(i+1,j+1);
            end
            if i<N
                P(i,j)=P(i,j)+l1*(s-l1)*F(i+1,j);
            end
            if j<N
                P(i,j)=P(i,j)+(s-l1)*l2*F(i,j+1);
            end
        end 
    end
    P=P/(s^2);
end

