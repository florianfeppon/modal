function [ d] = threshold( image )
%UNTITLED8 Summary of this function goes here
%   Detailed explanation goes here


end

