function [ P ] = getPatches(image,w)
%UNTITLED3 Assume image is a square
%   Detailed explanation goes here
%Size of the patches : 2*w+1
w1 = 2*w+1;
n=size(image,1);
% location of pixels
[Y,X] = meshgrid(1:n,1:n);
% offsets
[dY,dX] = meshgrid(-w:w,-w:w);
% location of pixels to extract
dX = reshape(dX, [1 1 w1 w1]);
dY = reshape(dY, [1 1 w1 w1]);
X = repmat(X, [1 1 w1 w1]) + repmat(dX, [n n 1 1]);
Y = repmat(Y, [1 1 w1 w1]) + repmat(dY, [n n 1 1]);
% Boundary condition handled by reflection
X(X<1) = 2-X(X<1); Y(Y<1) = 2-Y(Y<1);
X(X>n) = 2*n-X(X>n); Y(Y>n) = 2*n-Y(Y>n);
% Patch extractor operator
patch = @(f0)f0(X + (Y-1)*n);
P = patch(image);
end

