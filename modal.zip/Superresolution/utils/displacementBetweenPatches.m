function [ a,b ] = displacementBetweenPatches( P1,P2 )
%UNTITLED4 Summary of this function goes here
%   Detailed explanation goes here
    gt=-P1+P2;
    Gy=[1,2,1;0,0,0;-1,-2,-1];
    gyy = conv2(P1, Gy, 'same');
    Gx=[1,0,-1;2,0,-2;1,0,-1];
    gxx=conv2(P1,Gx,'same');
    det=sum(sum(gxx.*gxx))*sum(sum(gyy.*gyy))-sum(sum(gxx.*gyy))^2;
    a=(sum(sum(gxx.*gt))*sum(sum(gyy.*gyy))-sum(sum(gxx.*gyy))*sum(sum(gt.*gyy)))/det;
    b=(sum(sum(gxx.*gxx))*sum(sum(gyy.*gt))-sum(sum(gxx.*gt))*sum(sum(gxx.*gyy)))/det;
end

