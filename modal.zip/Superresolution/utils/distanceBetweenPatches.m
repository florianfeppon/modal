function [d] = distanceBetweenPatches(P0, P1)
%DISTANCEBETWEENPATCHES Computes the distance between two given patches
%   

d = sum(sum((P0-P1).^2));
end

