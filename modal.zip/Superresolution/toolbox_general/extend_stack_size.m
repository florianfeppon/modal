function extend_stack_size(mult)

% does nothing