function M = sum3(M,k)

% for Scilab compatibility
    
if nargin<2
    k = 3;
end
M = sum(M,k);
